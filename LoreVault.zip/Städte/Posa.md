---
NoteIcon: 
tags: 
Community-Size: small
Alignment: good
type: Dorf
politics: Bürgermeister von Voigt bestimmt
leader: "[[NPCs/BürgermeisterVonPoza]]"
guildsgroups: 
region: "[[Bolumia]]"
size: small
population: 200
commonraces: Mensch
religion: "[[]]"
exports:
  - "[[Eisen]]"
  - "[[Kupfer]]"
imports:
  - "[[Holz]]"
---
> [!infobox]
> # `=this.file.name`
> ###### Geography
> Type |  Stat |
> ---|---|
> Type | `=this.type` |
> Size | `=this.size` |
> Region | `=this.region` |
> ###### Politics
> Type |  Stat |
> ---|---|
> Govt Type | `=this.politics` |
> Ruler | `=this.leader` |
> Defense | `=this.defences` |
> ###### Organizations
> Type |  Stat |
> ---|---|
> Guilds & Groups | `=this.guildsgroups` |
> ###### Society
> Type |  Stat |
> ---|---|
> Population | `=this.population` |
> Races | `=this.commonraces` |
> Temples | `=this.religion`  |
> ###### Commerce
> Type |  Stat |
> ---|---|
> Exports | `=this.exports` |
> Imports | `=this.imports` |


# `=this.title`
## Overview
Minenstadt für [[Eisen]] und [[Kupfer]]
## Notable NPCs
Placeholder

## Story
Placeholder

## Points of Interest
Placeholder

## Valuables
Placeholder

## Background
Placeholder

## Additional Details
Placeholder




