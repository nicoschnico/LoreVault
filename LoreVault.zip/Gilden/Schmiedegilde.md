---
name: Schmiedegilde
home: "[[Grano]]"
leader: "[[null]]"
services: Maßanfertigung von Waffen/Rüstungen
shortDescription: Schmiede mit variierenden Fähigkeiten bieten ihre Dienste an
NoteIcon:
---
> [!infobox]
> # `=this.file.name`
> Hauptsitz:  `=this.home` 
> Dienste: `=this.services`
> Anführer: `=this.leader`
> Kurzbeschreibung: `=this.shortDescription` 

# Beschreibung
# Wichtige Personen
# Notizen
